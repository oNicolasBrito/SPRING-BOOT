package br.com.exemplo.api.modelo;

public @interface Entity {

}
